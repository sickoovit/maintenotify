import axios from "axios";

const WHATSAPP_API_URL = "https://graph.facebook.com/v21.0";
const { WHATSAPP_PHONE_NUMBER_ID, WHATSAPP_TOKEN } = process.env;

export async function sendWhatsAppMessage(to, message) {
  const url = `${WHATSAPP_API_URL}/${WHATSAPP_PHONE_NUMBER_ID}/messages`;

  const payload = {
    messaging_product: "whatsapp",
    to,
    type: "text",
    text: { body: message },
  };

  const res = await axios.post(url, payload, {
    headers: {
      Authorization: `Bearer ${WHATSAPP_TOKEN}`,
      "Content-Type": "application/json",
    },
  });

  return res.data;
}
